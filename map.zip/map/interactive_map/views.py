from django.shortcuts import render, redirect
from .models import *

# Create your views here.

def index(request):
    kilometers = Kilometers.objects.all()
    artificial_construction = Artificial_Construction.objects.all()
    station = Station.objects.all()
    sections_kilometers = SectionsKilometers.objects.all()

    context = {
        'kilometers': list(kilometers.values()),
        'artificial_construction': list(artificial_construction),
        'station': list(station.values()),
        'sections_kilometers': list(sections_kilometers.values())
    }

    return render(request, 'interactive_map/index.html', context=context)